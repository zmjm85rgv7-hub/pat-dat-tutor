PAT DAT Tutor website

Open index.html in any browser.

The site uses real photography hosted by Unsplash (not AI-generated images). Internet access is required for those photos to load.

Before publishing:
1. Replace the demo booking form with your preferred scheduler/payment provider.
2. Add your contact email and/or social accounts.
3. Add your preferred meeting platform.
4. Consider adding your own real headshot and testimonial(s) once available.

The site includes independent-service/trademark disclaimers and avoids claiming affiliation with DAT Booster, DAT Bootcamp, or the ADA.
